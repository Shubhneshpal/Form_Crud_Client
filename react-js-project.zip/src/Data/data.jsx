import Dosa from "../Images/dosa.jpg"
import Chola from "../Images/chhola.jpg"
import Idli from "../Images/idli.jpg"
import MasalaDosa from "../Images/masala.jpg"
import Paneer from "../Images/paneer.jpg"
import Gujrati from "../Images/gujrati.jpeg"

export const MenuList = [
  {
    name: "Dosa",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image: Dosa,
    price: 200,
  },
  {
    name: "Chola",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image: Chola,
    price: 250,
  },
  {
    name: "Idli Sambhar",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image: Idli,
    price: 300,
  },
  {
    name: "Masala Dosa",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image: MasalaDosa,
    price: 100,
  },
  {
    name: "Paneer",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image: Paneer,
    price: 400,
  },
  {
    name: "Gujrati",
    description:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Placeat, ab!",
    image: Gujrati,
    price: 500,
  },
];