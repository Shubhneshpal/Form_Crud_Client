import React from 'react'
import Layout from '../Components/Layout'

const NoPage = () => {
  return (
    <Layout>
      
    </Layout>
  )
}

export default NoPage
